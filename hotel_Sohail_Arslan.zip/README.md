# hotel
An application that uses java and mysql to show the hotel reservations and clients
